﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

class Program
{
    static void Main()
    {
        List<string> correosEncontrados = new List<string>();
        string patronCorreo = @"[a-zA-Z0-9._-]+@[a-zA-Z.]+\.[a-zA-Z]+";
        string entrada;

        Console.WriteLine("Ingresa líneas de texto que puedan contener correos electrónicos.");
        Console.WriteLine("Escribe 'ver' para mostrar todos los correos encontrados o 'salir' para terminar.");

        while (true)
        {
            Console.Write("Texto: ");
            entrada = Console.ReadLine();

            if (entrada.ToLower() == "ver")
            {
                Console.WriteLine("\nCorreos encontrados:");
                if (correosEncontrados.Count == 0)
                {
                    Console.WriteLine("No se ha encontrado ningún correo.");
                }
                else
                {
                    foreach (string correo in correosEncontrados)
                    {
                        Console.WriteLine(correo);
                    }
                }
                Console.WriteLine();
            }
            else if (entrada.ToLower() == "salir")
            {
                break;
            }
            else
            {
                MatchCollection coincidencias = Regex.Matches(entrada, patronCorreo);
                foreach (Match match in coincidencias)
                {
                    if (!correosEncontrados.Contains(match.Value))
                    {
                        correosEncontrados.Add(match.Value);
                    }
                }
            }
        }

        Console.WriteLine("Programa finalizado.");
    }
}
