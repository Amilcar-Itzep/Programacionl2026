﻿using System;

class Programa
{
    static void CalcularDescuentos(double[,] compras)
    {
        int numClientes = compras.GetLength(0);
        int numCompras = compras.GetLength(1);

        for (int i = 0; i < numClientes; i++)
        {
            double total = 0;

            for (int j = 0; j < numCompras; j++)
            {
                total += compras[i, j];
            }

            double descuento = 0;

            if (total >= 100 && total <= 1000)
            {
                descuento = total * 0.10;
            }
            else if (total > 1000)
            {
                descuento = total * 0.20;
            }

            double totalConDescuento = total - descuento;

            Console.WriteLine($"Cliente {i + 1}: Total = {total:C2}, Descuento = {descuento:C2}, Total con descuento = {totalConDescuento:C2}");
        }
    }

    static void Main()
    {
        double[,] comprasClientes = new double[5, 5]
        {
            { 20, 30, 10, 15, 5 },      // Total: 80 → Sin descuento
            { 100, 200, 300, 150, 250 },// Total: 1000 → 10%
            { 500, 600, 200, 100, 150 },// Total: 1550 → 20%
            { 10, 10, 10, 10, 10 },     // Total: 50 → Sin descuento
            { 400, 400, 400, 100, 100 } // Total: 1400 → 20%
        };

        CalcularDescuentos(comprasClientes);
    }
}
