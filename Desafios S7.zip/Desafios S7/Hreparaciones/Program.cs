﻿using System;
using System.Collections.Generic;
using System.IO;

// Clase base Auto
class Auto
{
    public string Marca { get; set; }
    public string Modelo { get; set; }

    public Auto(string marca, string modelo)
    {
        Marca = marca;
        Modelo = modelo;
    }

    // Método virtual para sobrescribir en subclases
    public virtual void Reparar(string detalle)
    {
        Console.WriteLine($"Reparando {Marca} {Modelo}: {detalle}");
    }

    // Historia de Reparaciones (leer de archivo)
    public virtual void HistoriaDeReparaciones()
    {
        string archivo = $"{Marca}_{Modelo}_reparaciones.txt";
        if (File.Exists(archivo))
        {
            Console.WriteLine($"--- Historial de reparaciones de {Marca} {Modelo} ---");
            string[] lineas = File.ReadAllLines(archivo);
            foreach (string linea in lineas)
            {
                Console.WriteLine(linea);
            }
        }
        else
        {
            Console.WriteLine("No hay historial de reparaciones.");
        }
    }
}

// Subclase BMW
class BMW : Auto
{
    public BMW(string modelo) : base("BMW", modelo) { }

    // Sobrescribir Reparar y guardar en archivo
    public override void Reparar(string detalle)
    {
        string archivo = $"{Marca}_{Modelo}_reparaciones.txt";
        string entrada = $"{DateTime.Now}: {detalle}";
        File.AppendAllText(archivo, entrada + Environment.NewLine);
        Console.WriteLine($"Reparación registrada: {entrada}");
    }

    // (Hereda HistoriaDeReparaciones desde Auto)
}

// Método Main
class Programa
{
    static void Main()
    {
        BMW miBMW = new BMW("X5");

        // Registrar reparaciones
        miBMW.Reparar("Cambio de aceite");
        miBMW.Reparar("Revisión de frenos");

        // Mostrar historial
        miBMW.HistoriaDeReparaciones();
    }
}

