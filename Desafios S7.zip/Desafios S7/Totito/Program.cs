﻿using System;

class ToTiTo
{
    static string[,] tablero = new string[3, 3];
    static string jugadorActual = "X";

    static void Main()
    {
        InicializarTablero();

        while (true)
        {
            MostrarTablero();
            Console.WriteLine($"Turno del jugador {jugadorActual}");
            Console.Write("Ingresa la fila (0-2): ");
            int fila = LeerNumero();
            Console.Write("Ingresa la columna (0-2): ");
            int columna = LeerNumero();

            if (tablero[fila, columna] != " ")
            {
                Console.WriteLine("¡Esa casilla ya está ocupada! Intenta de nuevo.");
                continue;
            }

            tablero[fila, columna] = jugadorActual;

            if (VerificarGanador())
            {
                MostrarTablero();
                Console.WriteLine($"🎉 ¡El jugador {jugadorActual} ha ganado!");
                break;
            }

            if (TableroLleno())
            {
                MostrarTablero();
                Console.WriteLine("😐 ¡Empate!");
                break;
            }

            jugadorActual = (jugadorActual == "X") ? "O" : "X";
        }
    }

    static void InicializarTablero()
    {
        for (int i = 0; i < 3; i++)
            for (int j = 0; j < 3; j++)
                tablero[i, j] = " ";
    }

    static void MostrarTablero()
    {
        Console.Clear();
        Console.WriteLine("   0   1   2");
        for (int i = 0; i < 3; i++)
        {
            Console.Write(i + "  ");
            for (int j = 0; j < 3; j++)
            {
                Console.Write(tablero[i, j]);
                if (j < 2) Console.Write(" | ");
            }
            Console.WriteLine();
            if (i < 2) Console.WriteLine("  -----------");
        }
    }

    static bool VerificarGanador()
    {
        for (int i = 0; i < 3; i++)
        {
            // Filas y columnas
            if ((tablero[i, 0] == jugadorActual && tablero[i, 1] == jugadorActual && tablero[i, 2] == jugadorActual) ||
                (tablero[0, i] == jugadorActual && tablero[1, i] == jugadorActual && tablero[2, i] == jugadorActual))
                return true;
        }

        // Diagonales
        if ((tablero[0, 0] == jugadorActual && tablero[1, 1] == jugadorActual && tablero[2, 2] == jugadorActual) ||
            (tablero[0, 2] == jugadorActual && tablero[1, 1] == jugadorActual && tablero[2, 0] == jugadorActual))
            return true;

        return false;
    }

    static bool TableroLleno()
    {
        foreach (string casilla in tablero)
            if (casilla == " ")
                return false;
        return true;
    }

    static int LeerNumero()
    {
        while (true)
        {
            if (int.TryParse(Console.ReadLine(), out int num) && num >= 0 && num <= 2)
                return num;
            Console.Write("Entrada inválida. Intenta con un número entre 0 y 2: ");
        }
    }
}
