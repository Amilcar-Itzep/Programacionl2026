﻿using System;
using System.Collections.Generic;

class Programa
{
    static List<string> tareas = new List<string>();

    static void Main()
    {
        bool continuar = true;

        while (continuar)
        {
            Console.Clear();
            Console.WriteLine("===== LISTA DE TAREAS =====");
            Console.WriteLine("1. Mostrar tareas");
            Console.WriteLine("2. Agregar tarea");
            Console.WriteLine("3. Eliminar tarea");
            Console.WriteLine("4. Salir");
            Console.Write("Selecciona una opción: ");
            string opcion = Console.ReadLine();

            switch (opcion)
            {
                case "1":
                    MostrarTareas();
                    break;
                case "2":
                    AgregarTarea();
                    break;
                case "3":
                    EliminarTarea();
                    break;
                case "4":
                    continuar = false;
                    break;
                default:
                    Console.WriteLine("Opción inválida. Presiona Enter para continuar...");
                    Console.ReadLine();
                    break;
            }
        }

        Console.WriteLine("¡Gracias por usar la lista de tareas!");
    }

    static void MostrarTareas()
    {
        Console.Clear();
        Console.WriteLine("===== TAREAS =====");

        if (tareas.Count == 0)
        {
            Console.WriteLine("No hay tareas registradas.");
        }
        else
        {
            for (int i = 0; i < tareas.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {tareas[i]}");
            }
        }

        Console.WriteLine("Presiona Enter para continuar...");
        Console.ReadLine();
    }

    static void AgregarTarea()
    {
        Console.Clear();
        Console.Write("Escribe la nueva tarea: ");
        string nuevaTarea = Console.ReadLine();
        if (!string.IsNullOrWhiteSpace(nuevaTarea))
        {
            tareas.Add(nuevaTarea);
            Console.WriteLine("Tarea agregada con éxito.");
        }
        else
        {
            Console.WriteLine("La tarea no puede estar vacía.");
        }
        Console.WriteLine("Presiona Enter para continuar...");
        Console.ReadLine();
    }

    static void EliminarTarea()
    {
        Console.Clear();
        MostrarTareas();

        if (tareas.Count == 0)
            return;

        Console.Write("Escribe el número de la tarea a eliminar: ");
        if (int.TryParse(Console.ReadLine(), out int indice) && indice >= 1 && indice <= tareas.Count)
        {
            tareas.RemoveAt(indice - 1);
            Console.WriteLine("Tarea eliminada.");
        }
        else
        {
            Console.WriteLine("Número inválido.");
        }

        Console.WriteLine("Presiona Enter para continuar...");
        Console.ReadLine();
    }
}
