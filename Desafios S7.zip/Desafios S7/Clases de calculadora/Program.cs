﻿using System;

class Calculadora
{
    // Atributos
    public string Marca { get; set; }
    public string Serie { get; set; }

    // Constructor
    public Calculadora(string marca, string serie)
    {
        Marca = marca;
        Serie = serie;
    }

    // Métodos básicos
    public double Sumar(double a, double b) => a + b;
    public double Restar(double a, double b) => a - b;
    public double Multiplicar(double a, double b) => a * b;
    public double Dividir(double a, double b)
    {
        if (b == 0)
            throw new DivideByZeroException("No se puede dividir entre cero.");
        return a / b;
    }
}

// Subclase que hereda de Calculadora
class CalculadoraCientifica : Calculadora
{
    // Constructor
    public CalculadoraCientifica(string marca, string serie) : base(marca, serie) { }

    // Métodos científicos
    public double Potencia(double baseNum, double exponente) => Math.Pow(baseNum, exponente);
    public double Raiz(double numero) => Math.Sqrt(numero);
    public double Modulo(double a, double b) => a % b;
    public double Logaritmo(double numero) => Math.Log10(numero); // log base 10
}

// Método principal
class Programa
{
    static void Main()
    {
        // Instancia de Calculadora básica
        Calculadora calcBasica = new Calculadora("Casio", "B100");
        Console.WriteLine("=== CALCULADORA BÁSICA ===");
        Console.WriteLine($"Marca: {calcBasica.Marca}, Serie: {calcBasica.Serie}");
        Console.WriteLine($"5 + 3 = {calcBasica.Sumar(5, 3)}");
        Console.WriteLine($"5 - 3 = {calcBasica.Restar(5, 3)}");
        Console.WriteLine($"5 * 3 = {calcBasica.Multiplicar(5, 3)}");
        Console.WriteLine($"5 / 3 = {calcBasica.Dividir(5, 3)}");

        // Instancia de Calculadora científica
        CalculadoraCientifica calcCientifica = new CalculadoraCientifica("Texas Instruments", "TI-84");
        Console.WriteLine("\n=== CALCULADORA CIENTÍFICA ===");
        Console.WriteLine($"Marca: {calcCientifica.Marca}, Serie: {calcCientifica.Serie}");
        Console.WriteLine($"2 ^ 4 = {calcCientifica.Potencia(2, 4)}");
        Console.WriteLine($"Raíz de 16 = {calcCientifica.Raiz(16)}");
        Console.WriteLine($"10 % 3 = {calcCientifica.Modulo(10, 3)}");
        Console.WriteLine($"Logaritmo base 10 de 1000 = {calcCientifica.Logaritmo(1000)}");
    }
}
