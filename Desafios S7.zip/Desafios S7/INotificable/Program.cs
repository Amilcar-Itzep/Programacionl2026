﻿using System;

// Interfaz
interface INotificable
{
    void Notifica(string mensaje);
}

// Implementación: Notificación por Email
class NotificacionEmail : INotificable
{
    public string DireccionCorreo { get; set; }

    public NotificacionEmail(string correo)
    {
        DireccionCorreo = correo;
    }

    public void Notifica(string mensaje)
    {
        Console.WriteLine($"Enviando Email a {DireccionCorreo}: {mensaje}");
    }
}

// Implementación: Notificación por WhatsApp
class NotificacionWhatsap : INotificable
{
    public string NumeroTelefono { get; set; }

    public NotificacionWhatsap(string numero)
    {
        NumeroTelefono = numero;
    }

    public void Notifica(string mensaje)
    {
        Console.WriteLine($"Enviando WhatsApp al número {NumeroTelefono}: {mensaje}");
    }
}

// Implementación: Notificación por SMS
class NotificacionSMS : INotificable
{
    public string NumeroTelefono { get; set; }

    public NotificacionSMS(string numero)
    {
        NumeroTelefono = numero;
    }

    public void Notifica(string mensaje)
    {
        Console.WriteLine($"Enviando SMS al número {NumeroTelefono}: {mensaje}");
    }
}

// Método Main
class Programa
{
    static void Main()
    {
        // Instancias de cada tipo de notificación
        INotificable email = new NotificacionEmail("amilcaritzepvicente@gmail.com");
        INotificable whatsapp = new NotificacionWhatsap("+50211223344");
        INotificable sms = new NotificacionSMS("+50211223344");

        Console.WriteLine("=== Notificaciones ===");
        email.Notifica("Tu pedido ha sido confirmado.");
        whatsapp.Notifica("Tu pedido llegará en 30 minutos.");
        sms.Notifica("Gracias por tu compra.");
    }
}

